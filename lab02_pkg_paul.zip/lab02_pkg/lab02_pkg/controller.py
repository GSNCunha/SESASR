# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
from rclpy.node import Node
import numpy as np # type: ignore
from std_msgs.msg import Bool
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Pose
from sensor_msgs.msg import LaserScan


class Controller(Node):

    def __init__(self):
        super().__init__('controller')
        self.subscription = self.create_subscription(
            Pose,
            '/odom',
            self.controller_listener_odom,
            10)
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.controller_listener_laser,
            10)
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)    
        self.declare_parameter('max_linvel', 0.22)
        self.declare_parameter('max_angvel', 1.5)
        self.declare_parameter('control_freq', 5.0)
        self.maxlinvel = self.get_parameter('max_linvel').get_parameter_value().double_value
        self.maxangvel = self.get_parameter('max_angvel').get_parameter_value().double_value
        controlfreq = self.get_parameter('control_freq').get_parameter_value().double_value
        timer_period = 1/controlfreq  # seconds
        self.timer = self.create_timer(timer_period, self.controller_callback)
        self.xpos = 0
        self.ypos = 0
        self.yaw = 0
        self.tooclosedist = 0.3
        self.tooclose = False
        self.distances = []
        self.go = False

    def controller_callback(self):
        msgout = Twist()
        threshold = 1
        fov = 50
        if (self.distances[0:int(fov/2)] > threshold).any() & (self.distances[-int(fov/2):] > threshold).any():
            self.go = True
        elif (self.distances[-90] <= self.distances[90]).any():
            self.go = False
            self.turnright = False
        elif (self.distances[90] <= self.distances[-90]).any():
            self.go = False
            self.turnright = True

        if self.go:
            msgout.angular.z = 0.0
            msgout.linear.x = self.maxlinvel
        elif self.turnright:
            msgout.linear.x = 0.0
            msgout.angular.z = -self.maxangvel
        else:
            msgout.linear.x = 0.0
            msgout.angular.z = self.maxangvel
        
        self.publisher_.publish(msgout)
        self.get_logger().info('x_vel = {xvel}, yaw_vel = {yvel}'.format(xvel=msgout.linear.x,yvel=msgout.angular.z))

    def controller_listener_odom(self,msg):
        self.xpos = msg.pose.pose.position.x
        self.ypos = msg.pose.pose.position.y
        self.yaw = msg.twist.twist.angular.z

    def controller_listener_laser(self,msg):
        self.distances = np.array(msg.ranges)
        for i in range(len(self.distances)):
            if self.distances[i] > msg.range_max:
                self.distances[i] = msg.range_max
            elif self.distances[i] < msg.range_min:
                self.distances[i] = msg.range_min



def main(args=None):
    rclpy.init(args=args)

    controller = Controller()

    rclpy.spin(controller)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    controller.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
